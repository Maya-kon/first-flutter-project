import "package:flutter/material.dart";

class MyScreenDesign extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new _MyScreenDesign();
  }
}

class _MyScreenDesign extends State<MyScreenDesign> {
  @override

  Widget build(BuildContext context) {
    // TODO: implement build
    return new Material(
        child: new Container(
            child: new Column(children: <Widget>[
              Padding(
                padding: EdgeInsets.only(top: 20,bottom: 50),
              ),
              new Row(
                children: <Widget>[
                  Padding(padding: EdgeInsets.only(top: 50),),
                  new Text("  Registration :", style:TextStyle(fontSize: 30),),

                ],
              ) ,
              Padding(padding: EdgeInsets.only(top: 50,bottom: 50,right: 20,left: 20),),
              new TextField(

                autocorrect: true,
                keyboardType: TextInputType.emailAddress,
                decoration: new InputDecoration(
                    icon: Icon(
                      Icons.email,
                    ),
                    labelText: "Email:",
                    hintText: "user@gmail.com"),
              ),
              new TextField(
                autocorrect: true,
                keyboardType: TextInputType.visiblePassword,
                decoration: new InputDecoration(
                    icon: Icon(
                      Icons.lock,
                    ),
                    labelText: "Password :",
                    hintText: "************"),

              ),
              Padding(padding: EdgeInsets.only(top: 30,right: 20,left: 20),),
                RaisedButton(
                  onPressed: () {},
                  color: Colors.cyan,
                  child: new Text("Log in"),
                ),

              Padding(padding: EdgeInsets.only(top: 10,bottom: 30,right: 20,left: 20),),
              RaisedButton(
                onPressed: () {},
                color: Colors.cyan,
                child: new Text("Sign up"),
              ),

                ],
              ) ,
            )
        );
  }
}

/* 1-
 child: new Column(   OR      child: new Row(
            children: <Widget>[
              Padding(padding: EdgeInsets.only(top: 50),),
              new Text("First element", style:TextStyle(fontSize: 20),),
              Padding(padding: EdgeInsets.only(top: 50),),
              Expanded (child: new Text("second element", style:TextStyle(fontSize: 20))),
            ],
    )

 2-
 child: new Container(
            child: new Row(children: <Widget>[
      Padding(
        padding: EdgeInsets.only(top: 50),
      ),
      RaisedButton(
        onPressed: () {
          print("Hello MAYA");
        },
        color: Colors.deepOrange,
        child: new Text("MyButton"),
      ),
      FlatButton(
          child: new Text("I'm flat button"),
          onPressed: () {
            print("hi");
          }),
      new IconButton(onPressed: ()=>onButtonClick("Hello"), icon: new Icon(Icons.perm_identity),color: Colors.amber )
    ])));
  }
}

onButtonClick(String s) {
  print(s);
}*/


/*3-
new TextField(
controller: _txtCont1,
),
new TextField(
controller: _txtCont2,
),
new RaisedButton(onPressed: () {
String s = _txtCont1.value.text;
_txtCont2.text = s;
}),*/